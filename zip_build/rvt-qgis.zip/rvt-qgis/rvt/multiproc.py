# TODO: multiprocessing for QGIS not yet supported

def save_multiprocess_vis(dem_path, vis, default, custom_dir=None, save_float=True, save_8bit=False,
                          x_block_size=5000, y_block_size=5000, offset=None):
    raise Exception("Relief visualization toolbox multiprocessing in QGIS plugin not supported!")
